public class FireMonster extends Monster{

    public FireMonster(String name) {
        super();
    }

    public String attack(){
        return "Attack with Fire!";
    }
}
