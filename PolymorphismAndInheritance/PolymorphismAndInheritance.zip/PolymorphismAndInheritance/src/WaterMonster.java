public class WaterMonster extends Monster{

    public WaterMonster(String name) {
        super();
    }

    public String attack(){
        return "Attack with Water!";
    }
}
