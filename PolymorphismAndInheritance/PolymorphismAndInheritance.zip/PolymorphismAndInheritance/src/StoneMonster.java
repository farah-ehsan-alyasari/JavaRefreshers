public class StoneMonster extends Monster{

    public StoneMonster(String name) {
        super();
    }

    public String attack(){
        return "Attack with Stone!";
    }
}
