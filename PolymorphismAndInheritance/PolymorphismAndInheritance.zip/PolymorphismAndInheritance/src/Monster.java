public class Monster {
    private String name;

    public Monster(String name){
        this.name = name;
    }

    public Monster(){

    }
    public String attack(){
         return "i don't know how to attack";
    }
}
