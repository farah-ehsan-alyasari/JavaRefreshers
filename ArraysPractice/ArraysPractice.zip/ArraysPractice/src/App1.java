/*Write a program that creates an array of integers with a length of 3. Assign the values 1, 2, and 3 to the indexes. Print out each array element.
 */

public class App1 {
    public static void main(String[] args) {
        int[] arr = {1,2,3};
        for(int i : arr){
            System.out.println(i);
        }
    }
}
