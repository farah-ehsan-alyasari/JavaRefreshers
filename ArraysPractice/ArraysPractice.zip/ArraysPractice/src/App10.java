import java.util.Arrays;

/*Create an array that includes an integer, 3 strings, and 1 double. Print the array.
 */
public class App10 {
    public static void main(String[] args) {
        Object[] arr = {1, "str1", "str2", "str3", 4.0};
        System.out.println(Arrays.toString(arr));
    }
}
