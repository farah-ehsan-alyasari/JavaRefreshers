public class LogicalOperatorsDemo {
    public static void main(String[] args){
        boolean x = true;
        boolean y = false;
        System.out.println("x & y : " + (x & y));
        System.out.println("x && y : " + (x && y));
        System.out.println("x | y : " + (x | y));
        System.out.println("x || y: " + (x || y));
        System.out.println("x ^ y : " + (x ^ y));
        System.out.println("y ^ x : " + (y ^ x));
        System.out.println("!x : " + (!x));
        System.out.println("!y : " + (!y));
    }
}
