public class Main {
    public static void main(String[] args) {
        double area;
        int radius;
        final double PI = 3.1459;

        radius = 10;
        area = radius * radius * PI;

        System.out.println("Area is : " + area);
    }
}