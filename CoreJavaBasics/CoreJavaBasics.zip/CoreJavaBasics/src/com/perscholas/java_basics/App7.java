package com.perscholas.java_basics;

public class App7 {
    public static void main(String[] args)
    {
        final int a = 4;
        int b = 8;
        int res1 = b/a;
        System.out.println(res1);
        double res2 = (double)(b/a);
        System.out.println(res2);
    }
}
