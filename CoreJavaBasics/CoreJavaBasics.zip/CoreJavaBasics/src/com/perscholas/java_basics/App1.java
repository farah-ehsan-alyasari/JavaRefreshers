package com.perscholas.java_basics;

public class App1 {
    public static void main(String[] args)
    {
        int a = 4;
        int b = 5;
        int sum = 0;
        sum = a+b;
        System.out.println(sum);
    }

}
