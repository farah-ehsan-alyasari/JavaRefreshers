package com.perscholas.java_basics;

public class App5 {
    public static void main(String[] args)
    {
      double a = 10;
      double b = 20;

      double res = (b/a);
      int castedResult = (int)res;
      System.out.println(castedResult);
    }
}
