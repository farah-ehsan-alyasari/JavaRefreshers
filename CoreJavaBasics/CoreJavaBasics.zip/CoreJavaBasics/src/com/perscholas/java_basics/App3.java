package com.perscholas.java_basics;

public class App3 {
    public static void main(String[] args){
        int a = 10;
        double b = 5;
        double sum = a+b;
        //the sum must be a double
        System.out.println(sum);
    }

}
