package com.perscholas.java_basics;

public class App6 {
    public static void main(String[] args)
    {
        int x = 5;
        int y = 6;
        double q = y/x;
        System.out.println(q);
        q = (double)y;
        System.out.println(q);
    }
}
