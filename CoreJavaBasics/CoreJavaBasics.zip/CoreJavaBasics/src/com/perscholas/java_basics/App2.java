package com.perscholas.java_basics;

public class App2 {
    public static void main(String[] args)
    {
        double a = 2;
        double b = 4;
        double sum = a+b;
        System.out.println(sum);
    }
}
