public class App3 {
    /*Suppose the tuition for a university is $10,000 for the current year and increases by 7 percent every year.
    In how many years will the tuition be doubled?
    */

    /*
    1000 + 7x = 2000
    solve for x
    2000 - 1000 = 1000
    7x = 1000
    x = 1000/7
    x = 142

    i did this while sorta of sleepy, i don't know if it's right
    but something along these lines where we algebrically solve for x
    where x is the number of years it takes for tution to double if
    we increase tution 7 percent per year
    */
}
