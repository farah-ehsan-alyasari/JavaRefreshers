//Farah Alyasari

public class App1 {
    public static void main(String[] args)
    {
        /*
        (a) 1 decimal = 1 binary
        (b) 8 decimal ->
            2^3 = 1000 binary
        (c) 33 decimal ->
            32 16 8 4 2 1
            1   0 0 0 0 1
            = 100001 binary
        (d) 78 decimal ->
            64 32 16 8 4 2 1
            1   0  0 1 1 0 1
            = 1001101 binary
        (e) 787 decimal ->
            512 256 128 64 32 16 8 4 2 1
            1   1    0  0  0  1  0 0 1 1
            = 1100010011 binary
        (f) 33,987
           32768 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1
           1     0     0    0    0    1    0   0   1   1  0   0 0 0 1 1
           = 1000010011000011 binary
        */
    }
}
